var niuyifan=function()
{
	
	function sleep(millisecond) {
        return new Promise(resolve => {
            setTimeout(() => {
                resolve()
            }, millisecond)
        })
    };
	
	async function go() {
		t=document.getElementsByClassName("cc");
		 document.body.removeChild(t[0]);
		
	}

function ClickBtn()

{
if(document.URL.search("pinlite")!=-1)
{
a=decodeURIComponent(document.getElementsByClassName("_2Lgol")[0].src.split("url=")[1]).split("/"),
b=decodeURIComponent(document.getElementsByClassName("_2Lgol")[0].src.split("url=")[1]).split(a[3]),
c=b[0]+"originals"+b[1];//url地址
		var cc=0;
	if(c.search("jpg")!=-1)
	{
	cc=c.replace("jpg","png")
	}
	else
	{
		cc=c.replace("png","jpg")
		
	}

}
else if(document.URL.search("rabbit")!=-1)
{
	
	
	a=document.getElementsByClassName("_1Vy68 _22496 test")[0].children[3].src
	aa=a.split("/")
    b=a.split(aa[3])[1];
	c=a.split("?")[0]
    //d="https://i.pinimg.com/"+"originals"+c;
    //c=d
	
	if(c.search("jpg")!=-1)
	{
	cc=c.replace("jpg","png")
	}
	else
	{
		cc=c.replace("png","jpg")
		
	}
	
}

else
if(document.getElementsByClassName("item PicWaterfallist").length==0)
{
a=document.getElementsByClassName("_2w6RE")[0].children[3].src
aa=a.split("/")
b=a.split(aa[3])[1]
c=a.split("?")[0]
//d="https://i.pinimg.com"+c;
//c=d

var cc=0;
	if(c.search("jpg")!=-1)
	{
	cc=c.replace("jpg","png")
	}
	else
	{
		cc=c.replace("png","jpg")
		
	}

}
else
{
	//alert("");
	a=document.getElementsByClassName("main-box")[0].children[1].children[2].src;
	aa=a.split("/")
b=a.split(aa[3])[1]
c=b.split("?")[0]
d="https://i.pinimg.com/"+c;
c=d


var cc=0;
	if(c.search("jpg")!=-1)
	{
	cc=c.replace("jpg","png")
	}
	else
	{
		cc=c.replace("png","jpg")
		
	}

}
s = function(t) {
                if (t.length < 2)
                    return (e = t.charCodeAt(0)) < 128 ? t : e < 2048 ? a(192 | e >>> 6) + a(128 | 63 & e) : a(224 | e >>> 12 & 15) + a(128 | e >>> 6 & 63) + a(128 | 63 & e);
                var e = 65536 + 1024 * (t.charCodeAt(0) - 55296) + (t.charCodeAt(1) - 56320);
                return a(240 | e >>> 18 & 7) + a(128 | e >>> 12 & 63) + a(128 | e >>> 6 & 63) + a(128 | 63 & e)
            };

r=c
	
pp = function(t) { 
                f = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g;
                return window.btoa((String(t)).replace(f, s));
            };
hhh=pp(encodeURIComponent(r));
hhhh=pp(encodeURIComponent(cc));


var t = document.createElement("iframe");
t.className="cc"
t.style.display = "none";
t.src ="//ccddsd.bigbigwork.com/download/img?jhk-d=1&base64Url="+hhh+"&dashisousuo=OTAxMjE2OTQsLSzmnKrlkb3lkI3jgIEsMTYwOTUwNzU5MzMxMiwx";
document.body.appendChild(t)

var t2 = document.createElement("iframe");
t2.className="cc2"
t2.style.display = "none";
t2.src ="//ccddsd.bigbigwork.com/download/img?jhk-d=1&base64Url="+hhhh+"&dashisousuo=OTAxMjE2OTQsLSzmnKrlkb3lkI3jgIEsMTYwOTUwNzU5MzMxMiwx";
//document.body.appendChild(t2)
setTimeout(go,10000);
//document.body.removeChild(t)


}




    var  _tr = document.createElement("tr");

 

    var td1=document.createElement("td");

	td1.innerHTML= '<input type="button" style="background-color: #7ED321;width: 100px;height: 36px;color: #FFFFFF" value="原图解析下载";" />';

    

    _tr.appendChild(td1);

    var o=0;
	
	
	if(document.URL.search("pinlite")!=-1)
{
	
    o=document.getElementsByClassName("_2du3X")[0];
	}
	else if(document.URL.search("rabbit")!=-1&&document.URL.search("image")!=-1)
	{
		
		 o=document.getElementsByClassName("_OETy")[0];
		
	}
	else
	{if(document.getElementsByClassName("item PicWaterfallist").length==0)
		{
	o=document.getElementsByClassName("_3FGB2")[0];
		}
		else
		{
			
		o=document.getElementsByClassName("action-bar cl")[0];	
			
		}
	
	}

    o.appendChild(_tr);
	
_tr.addEventListener("click",ClickBtn,false)
	





}



var  abcd=function()
{
	if(document.URL.search("pinlite")!=-1)
 {
  if(document.getElementsByClassName("_2du3X")[0]==undefined)
    {
	console.log("hello2");
           setTimeout(abcd,5);
      
    }
 else
    {
      console.log("hello1");
      niuyifan();
    }   
 }
 else if(document.URL.search("tupian")!=-1)
	 
	 {
	 try
	  {
		 if(document.getElementsByClassName("item PicWaterfallist").length==0)
		 
		 {
			 
			 console.log("hello2");
			
           setTimeout(abcd,5);
			 
		 }
		 
		 else
		 {
			 console.log("hello1");
			
             niuyifan(); 
			 
			 
		 }
	  }
	  catch(err)
{
    console.log("hello2");
	
           setTimeout(abcd,5);
}
 
		 
		 
		 
	 }
	 
	 

else if(document.URL.search("rabbit")!=-1)
	
	{//https://rabbit.bigbigwork.com/image
		
		if(document.URL.search("image")!=-1)
		{
			if(document.getElementsByClassName("SRQ1L font-bold")[0]!=undefined)
			{
			niuyifan();
			}
			else
			{
				 setTimeout(abcd,5);
				
			}
		}
		
		else
		{
			
			 setTimeout(abcd,5);
		}
		
		
	}

else
 {
	
   if(document.getElementsByClassName("cell cell-0")[0]==undefined)
  {
	console.log("hello2");
           setTimeout(abcd,5);
      
  }
   else
  {
      console.log("hello1");
      niuyifan();
  }   	
	
	
	
 }
}

abcd();

